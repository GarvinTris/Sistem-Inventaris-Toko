public class Kelompok_Aset {
    public int id_kelompok_aset;
    public String nama_kelompok_aset;

    public Kelompok_Aset(int id_kelompok_aset, String nama_kelompok_aset) {
        this.id_kelompok_aset = id_kelompok_aset;
        this.nama_kelompok_aset = nama_kelompok_aset;
    }

    public int getId_kelompok_aset() {
        return id_kelompok_aset;
    }

    public void setId_kelompok_aset(int id_kelompok_aset) {
        this.id_kelompok_aset = id_kelompok_aset;
    }

    public String getNama_kelompok_aset() {
        return nama_kelompok_aset;
    }

    public void setNama_kelompok_aset(String nama_kelompok_aset) {
        this.nama_kelompok_aset = nama_kelompok_aset;
    }

}
