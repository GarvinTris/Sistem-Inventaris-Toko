package Interface;

public interface Inter {
    boolean isStock();

    int totalStock();

    String Stockinfo();
}