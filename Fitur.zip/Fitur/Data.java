import java.time.LocalDate;

public abstract class Data {
    public abstract String getSerial();

    public abstract LocalDate getTanggal_masuk();

    public abstract String getKondisi();
}
