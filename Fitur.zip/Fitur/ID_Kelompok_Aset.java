public class ID_Kelompok_Aset {
    private int Id_Kelompok_Aset;
    private String Nama_Kelompok_Aset;

    public ID_Kelompok_Aset() {
    }

    public ID_Kelompok_Aset(int Id_Kelompok_Aset, String Nama_Kelompok_Aset) {
        this.Id_Kelompok_Aset = Id_Kelompok_Aset;
        this.Nama_Kelompok_Aset = Nama_Kelompok_Aset;
    }

    public int getId_Kelompok_Aset() {
        return Id_Kelompok_Aset;
    }

    public void setId_Kelompok_Aset(int Id_Kelompok_Aset) {
        this.Id_Kelompok_Aset = Id_Kelompok_Aset;
    }

    public String getNama_Kelompok_Aset() {
        return Nama_Kelompok_Aset;
    }

    public void setNama_Kelompok_Aset(String Nama_Kelompok_Aset) {
        this.Nama_Kelompok_Aset = Nama_Kelompok_Aset;
    }
}
