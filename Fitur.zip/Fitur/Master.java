public class Master {

    private int idMaster; // INT(11)
    private User idUser; // INT(11) FK -> User
    private int noMaster; // INT(11)
    private String file; // VARCHAR(50)
    private int status; // INT(11)
    private int tanggalInput; // INT(11)
    private int dateCreated; // INT(11)

    public Master(int idMaster, User idUser, int noMaster, String file, int status, int tanggalInput, int dateCreated) {
        this.idMaster = idMaster;
        this.idUser = idUser;
        this.noMaster = noMaster;
        this.file = file;
        this.status = status;
        this.tanggalInput = tanggalInput;
        this.dateCreated = dateCreated;
    }

    public int getIdMaster() {
        return idMaster;
    }

    public void setIdMaster(int idMaster) {
        this.idMaster = idMaster;
    }

    public User getIdUser() {
        return idUser;
    }

    public void setIdUser(User idUser) {
        this.idUser = idUser;
    }

    public int getNoMaster() {
        return noMaster;
    }

    public void setNoMaster(int noMaster) {
        this.noMaster = noMaster;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getTanggalInput() {
        return tanggalInput;
    }

    public void setTanggalInput(int tanggalInput) {
        this.tanggalInput = tanggalInput;
    }

    public int getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(int dateCreated) {
        this.dateCreated = dateCreated;
    }

}
